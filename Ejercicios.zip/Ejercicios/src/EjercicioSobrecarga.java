public class EjercicioSobrecarga {

    public static void main(String[] args) {
        Calculadora calc = new Calculadora();
        System.out.println("Suma de enteros (4 + 6): " + calc.sumar(4, 6));
        System.out.println("Suma de decimales (1.1 + 2.2 + 3.3): " + calc.sumar(1.1, 2.2, 3.3));
    }
}

class Calculadora {
    public int sumar(int a, int b) {
        return a + b;
    }

    public double sumar(double a, double b, double c) {
        return a + b + c;
    }
}
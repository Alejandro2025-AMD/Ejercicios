import java.util.ArrayList;
import java.util.Scanner;

public class EjercicioColecciones {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> lista = new ArrayList<>();

        for (int i = 0; i < 3; i++) {
            System.out.print("Ingresa un nombre: ");
            String nombre = sc.nextLine();
            lista.add(nombre);
        }

        System.out.println("Nombres ingresados:");
        for (String nombre : lista) {
            System.out.println("- " + nombre);
        }
    }
}